const STORAGE_KEY = "literaryLab10_v1";
const RESOURCE_LIMIT = 8;

const matchPairs = [
  {author:"Михайло Коцюбинський",work:"Intermezzo"},
  {author:"Василь Стефаник",work:"Камінний хрест"},
  {author:"Ольга Кобилянська",work:"Valse mélancolique"},
  {author:"Володимир Винниченко",work:"Момент"}
];

const genreItems = [
  {work:"Мартин Боруля",genre:"Комедія"},
  {work:"Лісова пісня",genre:"Драма-феєрія"},
  {work:"Камінний хрест",genre:"Новела"},
  {work:"Intermezzo",genre:"Психологічна новела"}
];

const chronology = [
  {id:"contra",title:"«Contra spem spero!» — Леся Українка",year:1890},
  {id:"valse",title:"«Valse mélancolique» — Ольга Кобилянська",year:1898},
  {id:"stone",title:"«Камінний хрест» — Василь Стефаник",year:1900},
  {id:"intermezzo",title:"«Intermezzo» — Михайло Коцюбинський",year:1908},
  {id:"moment",title:"«Момент» — Володимир Винниченко",year:1910},
  {id:"forest",title:"«Лісова пісня» — Леся Українка",year:1911},
  {id:"blue",title:"«Блакитна Панна» — Микола Вороний",year:1912}
];

const activities = [
  {id:"portrait",title:"Авторський портрет Коцюбинського",desc:"Мініекспозиція про автора й імпресіонізм.",cost:3,value:8},
  {id:"forest",title:"Інтерактивна сцена «Лісова пісня»",desc:"Візуальна мапа персонажів і конфліктів.",cost:4,value:9},
  {id:"stone",title:"Вікторина за «Камінним хрестом»",desc:"Запитання про образи та проблематику.",cost:2,value:6},
  {id:"song",title:"Музичний блок «Чари ночі»",desc:"Літературно-музична пауза.",cost:2,value:5},
  {id:"blue",title:"Мапа символів «Блакитної Панни»",desc:"Візуальне розкриття символів поезії.",cost:1,value:4},
  {id:"valse",title:"Дискусія про «Valse mélancolique»",desc:"Обговорення мистецтва й самореалізації.",cost:3,value:7},
  {id:"contra",title:"Читання «Contra spem spero!»",desc:"Виразне читання та аналіз мотивів.",cost:1,value:3}
];

let state = loadState();
let currentMatch = {};
let currentGenres = {};
let timelineOrder = [];
let selectedChip = null;

function loadState(){
  try{
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved || {student:null,best:{},logs:[],optimizerSelection:[]};
  }catch(e){return {student:null,best:{},logs:[],optimizerSelection:[]};}
}
function saveState(){localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}
function nowLabel(){return new Date().toLocaleString("uk-UA",{dateStyle:"short",timeStyle:"short"});}
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function logEvent(task,status,score,details){
  state.logs.unshift({time:new Date().toISOString(),task,status,score,details});
  if(state.logs.length>300) state.logs=state.logs.slice(0,300);
  saveState(); renderReport();
}
function completeTask(id,title,score,max,details){
  const previous=Number(state.best[id]||0);
  state.best[id]=Math.max(previous,score);
  logEvent(title,`Спроба: ${score}/${max}`,score,details);
  updateProgress();
}
function bestTotal(){return Object.values(state.best).reduce((a,b)=>a+Number(b||0),0);}
function maxTotal(){return 38;}
function updateProgress(){
  const done=Object.keys(state.best).length;
  const pct=Math.round(bestTotal()/maxTotal()*100);
  document.getElementById("progressPercent").textContent=pct+"%";
  document.getElementById("progressBar").style.width=pct+"%";
  document.getElementById("completedCount").textContent=done+" із 4 місій";
  document.getElementById("pointsCount").textContent=bestTotal()+" / "+maxTotal()+" балів";
  ["match","genre","timeline","optimizer"].forEach(id=>{
    const el=document.getElementById("status-"+id);
    if(el) el.textContent=state.best[id]!==undefined?`Найкраще: ${state.best[id]}/${({match:4,genre:4,timeline:7,optimizer:23})[id]} балів`:"Ще не виконано";
  });
}
function showView(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  document.getElementById("view-"+name).classList.add("active");
  document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  document.querySelectorAll(".task-panel").forEach(p=>p.classList.add("hidden"));
  window.scrollTo({top:0,behavior:"smooth"});
  if(name==="report") renderReport();
}
function openTask(name){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active"));
  document.querySelectorAll(".task-panel").forEach(p=>p.classList.add("hidden"));
  document.getElementById("task-"+name).classList.remove("hidden");
  window.scrollTo({top:0,behavior:"smooth"});
}
function backToMissions(){document.querySelectorAll(".task-panel").forEach(p=>p.classList.add("hidden"));showView("missions");}
function setFeedback(id,text,type=""){
  const el=document.getElementById(id);el.textContent=text;el.className="feedback "+type;
}
function shuffle(array){const a=[...array];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

function renderMatch(){
  currentMatch={};
  const pool=document.getElementById("matchPool");
  const targets=document.getElementById("matchTargets");
  pool.innerHTML="";targets.innerHTML="";
  shuffle(matchPairs).forEach(pair=>{
    const chip=document.createElement("button");chip.className="drag-chip";chip.type="button";chip.draggable=true;
    chip.textContent=pair.work;chip.dataset.work=pair.work;
    chip.addEventListener("dragstart",e=>{selectedChip=pair.work;e.dataTransfer.setData("text/plain",pair.work);chip.classList.add("dragging");});
    chip.addEventListener("dragend",()=>chip.classList.remove("dragging"));
    chip.addEventListener("click",()=>{selectedChip=pair.work;document.querySelectorAll("#matchPool .drag-chip").forEach(x=>x.classList.toggle("selected",x.dataset.work===selectedChip));});
    pool.appendChild(chip);
  });
  shuffle(matchPairs).forEach(pair=>{
    const slot=document.createElement("div");slot.className="target-slot";slot.dataset.author=pair.author;
    slot.innerHTML=`<span class="target-name">${escapeHtml(pair.author)}</span><span class="target-answer">Перетягни твір сюди</span>`;
    slot.addEventListener("dragover",e=>{e.preventDefault();slot.classList.add("over");});
    slot.addEventListener("dragleave",()=>slot.classList.remove("over"));
    slot.addEventListener("drop",e=>{e.preventDefault();slot.classList.remove("over");assignMatch(slot,e.dataTransfer.getData("text/plain")||selectedChip);});
    slot.addEventListener("click",()=>{if(selectedChip)assignMatch(slot,selectedChip);});
    targets.appendChild(slot);
  });
}
function assignMatch(slot,work){
  if(!work)return;
  const previous=Object.keys(currentMatch).find(k=>currentMatch[k]===work);
  if(previous)delete currentMatch[previous];
  currentMatch[slot.dataset.author]=work;
  selectedChip=null;
  renderMatchState();
}
function renderMatchState(){
  document.querySelectorAll("#matchTargets .target-slot").forEach(slot=>{
    const work=currentMatch[slot.dataset.author];
    slot.querySelector(".target-answer").innerHTML=work?`<button class="drag-chip" type="button" data-remove="${escapeHtml(slot.dataset.author)}">${escapeHtml(work)} ×</button>`:"Перетягни твір сюди";
    slot.querySelector("[data-remove]")?.addEventListener("click",e=>{e.stopPropagation();delete currentMatch[e.currentTarget.dataset.remove];renderMatchState();});
  });
  document.querySelectorAll("#matchPool .drag-chip").forEach(chip=>{
    const used=Object.values(currentMatch).includes(chip.dataset.work);
    chip.classList.toggle("selected",chip.dataset.work===selectedChip);
    chip.style.opacity=used?".35":"1";chip.disabled=used;
  });
}
function checkMatch(){
  let score=0;const details=[];
  matchPairs.forEach(p=>{const ok=currentMatch[p.author]===p.work;if(ok)score++;details.push(`${p.author} — ${currentMatch[p.author]||"не обрано"}: ${ok?"правильно":"помилка"}`);});
  completeTask("match","Літературні пари",score,4,details.join("; "));
  setFeedback("matchFeedback",`Результат: ${score}/4. ${score===4?"Усі пари правильні!":"Переглянь правильні відповідності й спробуй ще раз."}`,score===4?"success":"error");
}

function renderGenre(){
  currentGenres={};
  const pool=document.getElementById("genrePool"),targets=document.getElementById("genreTargets");
  pool.innerHTML="";targets.innerHTML="";
  shuffle(genreItems).forEach(item=>{
    const chip=document.createElement("button");chip.className="drag-chip";chip.type="button";chip.draggable=true;chip.textContent=item.work;chip.dataset.work=item.work;
    chip.addEventListener("dragstart",e=>{selectedChip=item.work;e.dataTransfer.setData("text/plain",item.work);chip.classList.add("dragging");});
    chip.addEventListener("dragend",()=>chip.classList.remove("dragging"));
    chip.addEventListener("click",()=>{selectedChip=item.work;document.querySelectorAll("#genrePool .drag-chip").forEach(x=>x.classList.toggle("selected",x.dataset.work===selectedChip));});
    pool.appendChild(chip);
  });
  ["Комедія","Драма-феєрія","Новела","Психологічна новела"].forEach(genre=>{
    const zone=document.createElement("div");zone.className="genre-zone";zone.dataset.genre=genre;
    zone.innerHTML=`<h3>${genre}</h3><div class="zone-items"><span class="target-answer">Перетягни твір</span></div>`;
    zone.addEventListener("dragover",e=>{e.preventDefault();zone.classList.add("over");});
    zone.addEventListener("dragleave",()=>zone.classList.remove("over"));
    zone.addEventListener("drop",e=>{e.preventDefault();zone.classList.remove("over");assignGenre(zone,e.dataTransfer.getData("text/plain")||selectedChip);});
    zone.addEventListener("click",()=>{if(selectedChip)assignGenre(zone,selectedChip);});
    targets.appendChild(zone);
  });
}
function assignGenre(zone,work){
  if(!work)return;
  const old=Object.keys(currentGenres).find(k=>currentGenres[k]===work);if(old)delete currentGenres[old];
  currentGenres[zone.dataset.genre]=work;selectedChip=null;renderGenreState();
}
function renderGenreState(){
  document.querySelectorAll(".genre-zone").forEach(zone=>{
    const work=currentGenres[zone.dataset.genre];
    zone.querySelector(".zone-items").innerHTML=work?`<button class="drag-chip" type="button" data-remove="${escapeHtml(zone.dataset.genre)}">${escapeHtml(work)} ×</button>`:`<span class="target-answer">Перетягни твір</span>`;
    zone.querySelector("[data-remove]")?.addEventListener("click",e=>{e.stopPropagation();delete currentGenres[e.currentTarget.dataset.remove];renderGenreState();});
  });
  document.querySelectorAll("#genrePool .drag-chip").forEach(chip=>{
    const used=Object.values(currentGenres).includes(chip.dataset.work);chip.style.opacity=used?".35":"1";chip.disabled=used;chip.classList.toggle("selected",chip.dataset.work===selectedChip);
  });
}
function checkGenre(){
  let score=0;const details=[];
  genreItems.forEach(item=>{const found=Object.keys(currentGenres).find(k=>currentGenres[k]===item.work);const ok=found===item.genre;if(ok)score++;details.push(`${item.work} → ${found||"не розподілено"}: ${ok?"правильно":"помилка"}`);});
  completeTask("genre","Жанрова майстерня",score,4,details.join("; "));
  setFeedback("genreFeedback",`Результат: ${score}/4. ${score===4?"Чудово, усі жанри визначено правильно.":"Спробуй ще раз, звіряючись із довідником."}`,score===4?"success":"error");
}

function renderTimeline(){
  timelineOrder=shuffle(chronology.map(x=>x.id));drawTimeline();
}
function drawTimeline(){
  const list=document.getElementById("timelineList");list.innerHTML="";
  timelineOrder.forEach((id,index)=>{
    const item=chronology.find(x=>x.id===id);
    const li=document.createElement("li");li.className="timeline-item";li.draggable=true;li.dataset.id=id;
    li.innerHTML=`<span class="order-index">${index+1}</span><strong>${escapeHtml(item.title)}</strong><span class="order-controls"><button type="button" aria-label="Перемістити вище" data-dir="-1">↑</button><button type="button" aria-label="Перемістити нижче" data-dir="1">↓</button></span>`;
    li.addEventListener("dragstart",e=>{e.dataTransfer.setData("text/plain",id);li.classList.add("dragging");});
    li.addEventListener("dragend",()=>li.classList.remove("dragging"));
    li.addEventListener("dragover",e=>{e.preventDefault();li.classList.add("drag-over");});
    li.addEventListener("dragleave",()=>li.classList.remove("drag-over"));
    li.addEventListener("drop",e=>{e.preventDefault();li.classList.remove("drag-over");moveTimeline(e.dataTransfer.getData("text/plain"),id);});
    li.querySelectorAll("button").forEach(btn=>btn.addEventListener("click",e=>{e.stopPropagation();const i=timelineOrder.indexOf(id),j=i+Number(btn.dataset.dir);if(j>=0&&j<timelineOrder.length){[timelineOrder[i],timelineOrder[j]]=[timelineOrder[j],timelineOrder[i]];drawTimeline();}}));
    list.appendChild(li);
  });
}
function moveTimeline(from,to){
  if(!from||from===to)return;const a=timelineOrder.indexOf(from),b=timelineOrder.indexOf(to);if(a<0||b<0)return;
  timelineOrder.splice(a,1);timelineOrder.splice(b,0,from);drawTimeline();
}
function checkTimeline(){
  const correct=[...chronology].sort((a,b)=>a.year-b.year).map(x=>x.id);
  let score=0;timelineOrder.forEach((id,i)=>{if(id===correct[i])score++;});
  const details=timelineOrder.map((id,i)=>{const item=chronology.find(x=>x.id===id);return `${i+1}. ${item.title} (${item.year})`;}).join("; ");
  completeTask("timeline","Часова лінія",score,7,details);
  setFeedback("timelineFeedback",`Правильних позицій: ${score}/7. Правильна послідовність: ${chronology.map(x=>x.year).join(" → ")}.`,score===7?"success":"error");
}

function renderActivities(){
  const list=document.getElementById("activityList");list.innerHTML="";
  activities.forEach(item=>{
    const label=document.createElement("label");label.className="activity-option";
    const checked=(state.optimizerSelection||[]).includes(item.id);
    label.innerHTML=`<input type="checkbox" value="${item.id}" ${checked?"checked":""}><span><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.desc)}</small></span><span class="option-metrics">${item.cost} ресурси<br>${item.value} балів</span>`;
    label.querySelector("input").addEventListener("change",e=>{
      let selected=new Set(state.optimizerSelection||[]);
      if(e.target.checked)selected.add(item.id);else selected.delete(item.id);
      state.optimizerSelection=[...selected];saveState();updateOptimizer();
      const totals=optimizerTotals();logEvent("Симуляція фестивалю","Проміжний результат",totals.value,`Обрано: ${selected.map(id=>activities.find(x=>x.id===id).title).join(", ")||"нічого"}; ресурси ${totals.cost}/${RESOURCE_LIMIT}; бали ${totals.value}.`);
    });
    list.appendChild(label);
  });
  updateOptimizer();
}
function optimizerTotals(){
  const selected=state.optimizerSelection||[];
  return selected.reduce((acc,id)=>{const item=activities.find(x=>x.id===id);if(item){acc.cost+=item.cost;acc.value+=item.value;}return acc;},{cost:0,value:0});
}
function updateOptimizer(){
  const t=optimizerTotals();
  document.getElementById("usedResources").textContent=t.cost;
  document.getElementById("currentScore").textContent=t.value;
  document.getElementById("resourceBar").style.width=Math.min(100,t.cost/RESOURCE_LIMIT*100)+"%";
  document.getElementById("resourceHint").textContent=t.cost>RESOURCE_LIMIT?`Перевищено ліміт на ${t.cost-RESOURCE_LIMIT} одиниць.`:`Залишилося ${RESOURCE_LIMIT-t.cost} ресурсних одиниць.`;
  document.getElementById("resourceBar").style.background=t.cost>RESOURCE_LIMIT?"#c47c68":"#d6b36f";
}
function checkOptimizer(){
  const t=optimizerTotals();
  if(t.cost>RESOURCE_LIMIT){
    document.getElementById("optimizerFeedback").textContent=`План не проходить обмеження: використано ${t.cost} із ${RESOURCE_LIMIT} ресурсів. Скороти програму й перевір знову.`;
    document.getElementById("optimizerFeedback").className="optimizer-feedback error";
    logEvent("Оптимізація фестивалю","План перевищує ліміт",0,`Витрати ${t.cost}/${RESOURCE_LIMIT}; бали ${t.value}.`);
    return;
  }
  const score=t.value;
  const optimalSet=["portrait","stone","song","blue"].sort().join("|");
  const currentSet=[...(state.optimizerSelection||[])].sort().join("|");
  const isOptimal=score===23 && currentSet===optimalSet;
  completeTask("optimizer","Оптимізація фестивалю",score,23,`Обрані активності: ${(state.optimizerSelection||[]).map(id=>activities.find(x=>x.id===id).title).join(", ")||"не обрано"}; ресурси ${t.cost}/${RESOURCE_LIMIT}; результат ${score}/23.`);
  const fb=document.getElementById("optimizerFeedback");
  if(isOptimal){fb.textContent="Оптимальне рішення знайдено: 23 бали за 8 ресурсних одиниць. Ти максимально використав/використала доступний бюджет.";fb.className="optimizer-feedback success";}
  else if(score===23){fb.textContent="Ти досяг/досягла максимальної кількості балів! Перевір, чи всі обрані активності вкладаються в ресурсний ліміт.";fb.className="optimizer-feedback success";}
  else{fb.textContent=`Твій план дає ${score}/23 балів за ${t.cost}/${RESOURCE_LIMIT} ресурсних одиниць. Подумай, чи можна замінити одну з активностей на ефективнішу.`;fb.className="optimizer-feedback";}
}
function clearOptimizer(){
  state.optimizerSelection=[];saveState();renderActivities();
  document.getElementById("optimizerFeedback").textContent="Вибір скинуто. Спробуй побудувати іншу програму.";
  document.getElementById("optimizerFeedback").className="optimizer-feedback";
  const t=optimizerTotals();logEvent("Симуляція фестивалю","Вибір скинуто",0,`Проміжний стан: ресурси ${t.cost}/${RESOURCE_LIMIT}; балів ${t.value}.`);
}

function renderReport(){
  if(!state.student)return;
  const done=Object.keys(state.best).length;
  const summary=document.getElementById("reportSummary");
  summary.innerHTML=`<div class="summary-tile"><span>Найкращий результат</span><strong>${bestTotal()} / ${maxTotal()}</strong></div><div class="summary-tile"><span>Виконано місій</span><strong>${done} / 4</strong></div><div class="summary-tile"><span>Записів в історії</span><strong>${state.logs.length}</strong></div>`;
  document.getElementById("historyCount").textContent=`${state.logs.length} записів`;
  const list=document.getElementById("historyList");
  if(!state.logs.length){list.innerHTML='<p class="muted">Поки що записів немає. Виконай першу місію.</p>';return;}
  list.innerHTML=state.logs.map(item=>`<div class="history-item"><strong>${escapeHtml(item.task)}</strong><p>${escapeHtml(item.details||item.status||"")}</p><time>${new Date(item.time).toLocaleString("uk-UA",{dateStyle:"short",timeStyle:"short"})}</time></div>`).join("");
}
function buildPdfReport(){
  const s=state.student||{name:"Учень",className:"—"};
  const bestRows=[
    ["Літературні пари",state.best.match,4],
    ["Жанрова майстерня",state.best.genre,4],
    ["Часова лінія",state.best.timeline,7],
    ["Оптимізація фестивалю",state.best.optimizer,23]
  ];
  const logs=state.logs.map(item=>`<tr><td>${new Date(item.time).toLocaleString("uk-UA")}</td><td>${escapeHtml(item.task)}</td><td>${escapeHtml(item.status)}</td><td>${escapeHtml(item.details||"")}</td></tr>`).join("");
  const optimizer=optimizerTotals();
  const intermediate=(state.optimizerSelection||[]).map(id=>activities.find(x=>x.id===id)?.title).filter(Boolean).join(", ")||"Нічого не обрано";
  const report=document.getElementById("pdfReport");
  report.innerHTML=`
    <div style="font-family:Arial,sans-serif;color:#20332e">
      <div style="border-bottom:3px solid #c49b55;padding-bottom:12px;margin-bottom:18px">
        <div style="font-size:10px;letter-spacing:2px;color:#987746">ЛІТЕРАТУРНА ЛАБОРАТОРІЯ · 10 КЛАС</div>
        <h1 style="font-family:Georgia,serif;font-size:27px;margin:8px 0">Звіт про навчальні результати</h1>
        <p style="font-size:12px;margin:0;color:#65716a">Сформовано: ${new Date().toLocaleString("uk-UA")}</p>
      </div>
      <p><b>Учень/учениця:</b> ${escapeHtml(s.name)} &nbsp;&nbsp; <b>Клас:</b> ${escapeHtml(s.className)}</p>
      <div style="display:flex;gap:12px;margin:18px 0">
        <div style="padding:12px;background:#edf2eb;flex:1"><small>Найкращий результат</small><h2 style="margin:5px 0">${bestTotal()} / ${maxTotal()}</h2></div>
        <div style="padding:12px;background:#edf2eb;flex:1"><small>Виконано місій</small><h2 style="margin:5px 0">${Object.keys(state.best).length} / 4</h2></div>
        <div style="padding:12px;background:#edf2eb;flex:1"><small>Зафіксовано подій</small><h2 style="margin:5px 0">${state.logs.length}</h2></div>
      </div>
      <h2 style="font-family:Georgia,serif;font-size:18px">Підсумки за місіями</h2>
      <table style="width:100%;border-collapse:collapse;font-size:11px;margin-bottom:18px">
        <thead><tr style="background:#183d38;color:white"><th style="padding:8px;text-align:left">Місія</th><th style="padding:8px;text-align:left">Найкращий результат</th></tr></thead>
        <tbody>${bestRows.map(r=>`<tr><td style="border-bottom:1px solid #ddd;padding:8px">${r[0]}</td><td style="border-bottom:1px solid #ddd;padding:8px">${r[1]===undefined?"Не виконано":r[1]+" / "+r[2]}</td></tr>`).join("")}</tbody>
      </table>
      <h2 style="font-family:Georgia,serif;font-size:18px">Поточний проміжний стан симуляції</h2>
      <p style="font-size:11px"><b>Обрані активності:</b> ${escapeHtml(intermediate)}<br><b>Витрати:</b> ${optimizer.cost} / ${RESOURCE_LIMIT} ресурсних одиниць<br><b>Поточний результат:</b> ${optimizer.value} балів</p>
      <h2 style="font-family:Georgia,serif;font-size:18px">Повна історія спроб і проміжних результатів</h2>
      <table style="width:100%;border-collapse:collapse;font-size:9px;table-layout:fixed">
        <thead><tr style="background:#183d38;color:white"><th style="padding:6px;width:14%;text-align:left">Час</th><th style="padding:6px;width:17%;text-align:left">Завдання</th><th style="padding:6px;width:17%;text-align:left">Статус</th><th style="padding:6px;text-align:left">Деталі / проміжний результат</th></tr></thead>
        <tbody>${logs||'<tr><td colspan="4" style="padding:8px">Записів поки немає.</td></tr>'}</tbody>
      </table>
      <p style="font-size:9px;color:#78837c;margin-top:20px">Дані збережено локально у браузері. Цей звіт створено навчальним вебзастосунком; він не є офіційним документом оцінювання.</p>
    </div>`;
  return report;
}
async function downloadPdf(){
  const report=buildPdfReport();
  if(window.html2pdf){
    const filename=`zvit_${(state.student?.name||"uchень").trim().replace(/\s+/g,"_")}_${state.student?.className||"10kl"}.pdf`;
    // html2canvas не рендерить display:none, тому тимчасово виносимо звіт за межі екрана.
    report.style.display="block";
    report.style.position="absolute";
    report.style.left="-10000px";
    report.style.top="0";
    report.style.width="190mm";
    try{
      await window.html2pdf().set({
        margin:[10,10,10,10],filename,
        image:{type:"jpeg",quality:.96},
        html2canvas:{scale:2,useCORS:true,backgroundColor:"#ffffff"},
        jsPDF:{unit:"mm",format:"a4",orientation:"portrait"}
      }).from(report).save();
    }finally{
      report.style.display="none";
      report.style.position="";
      report.style.left="";
      report.style.top="";
      report.style.width="";
    }
  }else{
    alert("Бібліотека PDF не завантажилася. Відкриється вікно друку — обери «Зберегти як PDF».");
    window.print();
  }
}

function startApp(student){
  state.student=student;saveState();
  document.getElementById("registration").classList.add("hidden");
  document.getElementById("app").classList.remove("hidden");
  document.getElementById("welcomeName").textContent=student.name.split(" ")[0];
  const badge=document.getElementById("studentBadge");badge.textContent=student.className;badge.classList.remove("hidden");
  updateProgress();renderReport();
}

document.addEventListener("DOMContentLoaded",()=>{
  const form=document.getElementById("registerForm");
  if(state.student){
    document.getElementById("studentName").value=state.student.name;
    document.getElementById("studentClass").value=state.student.className;
    const note=document.createElement("p");note.className="muted";note.style.marginTop="8px";note.textContent="Знайдено попередній профіль на цьому пристрої. Продовжити можна з тими самими даними.";
    form.appendChild(note);
  }
  form.addEventListener("submit",e=>{
    e.preventDefault();
    const name=document.getElementById("studentName").value.trim();
    const className=document.getElementById("studentClass").value;
    if(!name||!className)return;
    startApp({name,className});
    logEvent("Профіль учня","Розпочато роботу",0,`Учень/учениця: ${name}; клас: ${className}.`);
  });
  document.querySelectorAll(".nav-link").forEach(btn=>btn.addEventListener("click",()=>showView(btn.dataset.view)));
  document.querySelectorAll(".mission-card").forEach(btn=>btn.addEventListener("click",()=>openTask(btn.dataset.jump)));
  document.querySelectorAll("[data-back]").forEach(btn=>btn.addEventListener("click",backToMissions));
  document.getElementById("checkMatch").addEventListener("click",checkMatch);
  document.getElementById("checkGenre").addEventListener("click",checkGenre);
  document.getElementById("checkTimeline").addEventListener("click",checkTimeline);
  document.getElementById("checkOptimizer").addEventListener("click",checkOptimizer);
  document.getElementById("clearOptimizer").addEventListener("click",clearOptimizer);
  document.getElementById("downloadPdf").addEventListener("click",downloadPdf);
  document.getElementById("downloadPdfTop").addEventListener("click",downloadPdf);
  document.getElementById("resetData").addEventListener("click",()=>{
    if(confirm("Очистити профіль, усі спроби та результати на цьому пристрої?")){
      localStorage.removeItem(STORAGE_KEY);state={student:null,best:{},logs:[],optimizerSelection:[]};location.reload();
    }
  });
  renderMatch();renderGenre();renderTimeline();renderActivities();
  if(state.student)startApp(state.student);
});
